package com.project.reportcardmanagement.service;

public interface LoginService {
    boolean validateUser(String username, String password);
}